AIR 1 Study Tracker — Android WebView project

This project wraps the offline HTML tracker in a native Android WebView.
It is a build-ready source project, NOT a prebuilt APK.

Build using GitHub Actions:
1. Create a GitHub repository.
2. Upload the contents of this folder to the repository (keep .github/workflows/build-apk.yml).
3. Open the repository's Actions tab.
4. Run "Build AIR 1 Study Tracker APK" (or push to main).
5. Download the artifact named AIR1-Study-Tracker-debug-apk.
6. Extract app-debug.apk and install it on your Android phone.

The app stores its data locally in its WebView storage. Export JSON backups regularly.
